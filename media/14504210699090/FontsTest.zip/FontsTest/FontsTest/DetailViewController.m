//
//  DetailViewController.m
//  FontsTest
//
//  Created by Yun on 15/3/13.
//  Copyright (c) 2015年 Yun. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()
@property (weak, nonatomic) IBOutlet UILabel *labEN;
@property (weak, nonatomic) IBOutlet UILabel *labCN;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = _fontName;
    // Do any additional setup after loading the view from its nib.
    _labCN.font = [UIFont fontWithName:_fontName size:15];
    _labEN.font = [UIFont fontWithName:_fontName size:15];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
