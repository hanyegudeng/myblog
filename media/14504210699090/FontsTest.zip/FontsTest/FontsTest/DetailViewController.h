//
//  DetailViewController.h
//  FontsTest
//
//  Created by Yun on 15/3/13.
//  Copyright (c) 2015年 Yun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController
@property (nonatomic, copy) NSString* fontName;
@end
