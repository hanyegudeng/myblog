//
//  FontsViewController.m
//  FontsTest
//
//  Created by Yun on 15/3/13.
//  Copyright (c) 2015年 Yun. All rights reserved.
//

#import "FontsViewController.h"
#import "DetailViewController.h"

@interface FontsViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) NSArray* fonts;
@property (nonatomic, strong) UITableView* tableView;
@end

@implementation FontsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"iOS字体测试";

    NSArray *familyNames = [UIFont familyNames];
    NSMutableArray *fontNames = [NSMutableArray array];
    for (NSString *family in familyNames) {
        [fontNames addObjectsFromArray:[UIFont fontNamesForFamilyName:family]];
    }
    self.fonts = [fontNames sortedArrayUsingSelector:@selector(compare:)];//对获取到的字体数字串按顺序排列，fonts 为一个NSArray。
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.fonts.count;;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString* strcell = @"strcell";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:strcell];
    if(!cell){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:strcell];
    }
    cell.textLabel.text = self.fonts[indexPath.row];
    cell.textLabel.font = [UIFont fontWithName:self.fonts[indexPath.row] size:15];
    cell.detailTextLabel.text = @"中文显示效果测试";
    cell.detailTextLabel.font = [UIFont fontWithName:self.fonts[indexPath.row] size:15];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DetailViewController* detail = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:nil];
    detail.fontName = self.fonts[indexPath.row];
    [self.navigationController pushViewController:detail animated:YES];
}
@end
